'''
A machine tool may be defined as a power driven machine which accomplishes the cutting or machining operations on it.
When machines perform the metal cutting operatons using the cutting tools mounted on them, they are called "machine tools."

Lathe:
Lathe is a machine tool employed, generally to produce circular objects. The main function of the lathe is to remove metal from a piece of work to give it the required shape and size.
Work piece is held rigidly by one of the work holding devices known as chuck. It is then turned against the cutting tool which will remove the metal from the workpiece in the form of chips.
To cut the material properly, the tool should be harder than the material of the workpiece. 

Parts of a Lathe:
1. Bed: The bed is the foundation part of a lathe and supports all its other parts. There are two precision machined guide ways on the top of the bed: outer guide ways and inner guide ways. The outer guide way supports the carriage assm=embly using saddle. The headstock and tailstock are mounted on the inner guideways.
2. Headstock: The housing comprising the stepped cone pulley and feed gear box is called the headstock of the lathe. The headstock is rigidly mounted on the inner guide ways of the lathe bed at its left end and it is not movable. The main spindle projects out from the headstock and is driven at multiple speeds. Headstock is also called the live center since it is power driven.
3. Tailstock: Tailstock is the movable part of the lathe that carries the dead center in it. It is mounted loosely on the inner guide ways of lathe bed on the right side and can be moved and locked in any position. It supports the free end of the work piece. Tailstock is also used to clamp tools such as twist drills and remaers for making holes, taps and dies for cutting threads.
4. Carriage Assembly: The carriage assembly serves to support the tool and rides over the outer guide ways longitudinally between headstock and tailstock. It is composed of 5 main parts:
    a) Saddle: Saddle is a H shaped casting that slides over the outer guide ways and serves as the base for the cross slide, compound rest and tool post.
    b) Cross slide: Cross slide is mounted on the saddle and enables the movement of the cutting tool in a lateral direction, perpendicular to the movement of the saddle, across the lathe bed either automatically or manually by means of cross feed hadn wheel. It supports the compund rest and the tool post.
    c) Compound rest: Compound rest is mounted on the top of the cross slide and supports the tool post. It has a circular base graduated in degrees and can be swivelled to any angle in the horizontal plane to facilitate the taper turning operation. There is no power feed to the compound rest. It is moved manually by the compound rest feed handle independent of the lathe cross feed. It supports the tool post and facilitates taper turning operation.
    d) Apron: Apron is mounted at the front of the saddle beneath it and houses carriage and cross slide mechanisms. The apron hand wheel moves carriage manually by means of the rack and pinion arrangement.
    e) Tool post: Tool post is mounted in the T-slot of the compound rest. The tool post clamps the tool holder in the proper position for carrying out various machining operations.
5. Lead Screw: Lead screw is a screw rod which runs longitudinally in the front of the lathe bed. The rotation of the lead screw moves the carriage to and fro longitudinally during thread cutting operation. It may alsi be used to provide motion for turning operations in laths that are not equipped with a feed rod.
6. Feed rod: The feed rod is a long shaft mounted in front of the lathe bed. The power is transmitted from the lathe spindle to the apron gears through a feed rodvia large number of gears, It facilitates automatic longitudinal movement of the carriage dyring tunring and lateral movement of the cross slide during facing operations. It is not used for thread cutting operation.
7. Main drive: It consists of an electric motor mounted in the lower left portion of the lathe in conjunction with the transmission system like belt or gear drive thereby driving the cone pulley. Various spindle speeds can be obtained by shifting the belt on different steps of the cone pulley. Spindle speeds can be further varied using the back gear arrangement by engaging or disengaging the same. Cone pulley drives the main spindle which is driven by the motor. Various spindle speeds can be obtained by shifting the belt on different steps of the cone pulley and also by using back gear arrangement.
8. Three Jaw Chuck: It holds the cylindrical workpiece and is self centred.


Specifications of a Lathe:
The size of the lathe is specified by the following as shown in the figure below:

1. Distance between centers: It is the maximum distance that can be obtained between the lathe centers. It represnets the maximum length of the work pice that can be held between centers.
2. Overall length of the bed: It is the maximum length of the bed starting from the headstock end to the tailstock end.
3. Swing of workpiece over the lathe bed: It is the largest diameter of the work piece that can be rotated without touching the bed.
4. Swing of workpiece over gap in the bed: It is the maximum diameter and the width of a work piece that can swing when the lathe has gap in the bed.

Classification of a Lathe:
Lathes are classified as:
1. Bench Lathe: This lathe is the smallest in the lathe family. It derives its name from the fact that it is mounted on a becnh. It has all the parts of a convetional lathe and is generally used for small and precision related work.
2. Speed Lathe: It derives its nae because of the very high speed of the headstock spindle. It is used in operations such as woodworking, polishing, spinning etc. It consists of a bed, a headstock, a tailstock and a tool post mounted on an adjustable slide. There is no feed box, lead screw or convetional type of carriage. The tool is mounted on the adjustable slide and is fed by hand control.

'''