'''
structure of a decision tree: root node which will basiclly contain the entire dataset. the first feature and split will be selected here
decision nodes: intenral nodes that apply conditions to the data
branches are the paths connecting nodes, each branch will correspond to an outcome of a decision
leaf nodes will have the final -red which will predict the majrity class

gini impurity: this measures how mixed classes are within a node: lower the impurity purer the class so the ml model will spplit the features again and again and then finally choose a feature ehich is the least mixed or has the least gini imputiry to split on.
lower gini impurity is better because a good split will create child nodes that are urer than the original node

entropy and info gain: entrop is the sum of propp into log to the base 2 of prop of each sample in a class.
entrop will be 0 when all samples belong to the same class
max when all classes are eqully rep

info gain: meausres how much a split reduces entropy, its equal to parent entropy-split entrop
higher info gain means better becaus =e , entropy meausres the uncertainity

okay so when its learning what happens is that all training samples are at the root, after examining possible feature splits and meausruing the impurity red prodcued by each split(gini, entropy). the best valid split will be chosen
the sample will be divided into child nodes and this process will be done again and again through recursion and it stops wehn a stoppig condition is reached

complexity of the tree can be meausred using  hyperparamters such as max depth which limits the max depth og the tree, min samples split which chooses the min nmber of samples to split a node
min samples leaf is the min number of samples allowed in a leaf and max leaf nodes limits the number of leaf nodes. criterion will select the impurity measure and ccp alpha controls the cost complexity pruining

pre pruning stops the tree from growing too complex as in it limits the depth, requries a min impurity red and a min number of samples per leaf

featureimportance: based on total red in impurity a feature that continuously produces uselful splits may receive a higher imp score.

accuracy is the total number of true positives plus true negatives upon the ttal number of preidctions, right/all

preciison is the total number of true postives upon number of false plus true

high accuracy doesnt mean that the model is good. recall is true positives upon true psotives plus false negatives

f1 score is 2 intoprecision into recall upon the sum of precision and recall

matthews correlation coefficient measures the agreement between actual and predicted labels.
its true positives into true negtaives minus false posiives into false negatives upon the square root of true plus fals,e tru and basiaclly a combo of tp fp tn fn
it ranges from -1 to 1 where 1 means perfect 0 means no correclation and -1 means inverse oreds

roc means receiver operating cjar it plots true positive rate which is true posotive upon true positive uponn false negative vs false positive rate which is false positive upon false psotive plus true negative
auc means area under the curve
auc=1 means perfect rnaking
for multiclass datsets, we use a one versus the rest approach:
- one class is positive the rest are negative and we continue 

cross validation, one feature split might given 94 percent accuracy when tested for validation 
k fold cross validation is basically dividing the training set into 5 pars, trains on folds 2 to 5 and then tests on 1 and then trains on folds 1, 3 to 5 and test on 2 
continue till all folds have been used fot validation and the 5 validation scores are averaged out

stratified k fold attemts to presrve class proportions in each fold which is useful when some of the classes are uncommon
k means clustering:
clusterig means grouping samples based on similairties in the features. 
k means divided the data into k clusters and each cluster will be rep by its centroid which is the mean of all poits assigned to the clsuter. the algo tries to minimised the within clusetr sum of squared dist 

te algoritm is choose k that is choose the number of clusters to be created
then initialize the centroids after which points will be assigned to clusters based on the nearest centrodi
then the centroids are recalucated
and this is repetaed again and again until the centroids stop moving significantly or a max number of iterations is reached
the optimal k can be selected using 2 methods:
1. elbow method: for each value calc the within cluster sum of squared errors called inetria
k incraeses interita decreseases the point where the curve begins to flatten is called the elbow
silhouette score compares how close a sample is to its own cluster vs other clusters 
if it is negative it means another cluster might be better



DBSCAN 
densirt based spatial clustering of applications with noise
it doesnt require the number of clusters to be specified in advance
instead it identifeies regions where samples are suffciciently dense
it can discover irregulalrly shaped clusters and identify points that dont belong to any dense region.
2 parameters: eps awhich defines the radius of a neighbourhood around a point
small epsilon means many isolated points
large epsilon may merge separate clusters 
min_samples specifeies how many samples lie within a points neighbourhood for that point point to qualify as a core point
a point needs at least 5 samples in its epslion nbd 
core points, border points and noise
core point a point with at least min samples samples in its eplsion nbd
border point is a point that does not satisify core point condt 
noise point is not a core point and is far apart
all points amrked as unvisited and then one of the pts is selcetd all points within its epsilon nbd are found, if nbd contains fewer samples 
point is a core point start a new cluster and expand it until no more points can be added

k distance plot 
calc dist to other points and find dist to its nearest neighbour, sort dists and plot in asc

both are unsupervised learning ty[es and k means needs number of clusters in adv ad k means uses centroid dbscan naturally identfies nose
]

principal component analysis
dimensionalty problem 
creates variables called princiapl componenets which are linear combos of original features
first pc captures greates varinae etc
covariance matrix is calculated and it describes the vraiances of indiviual fetaures and the relationships between pairs of features
the eigne vectors and valuea re calc and the components are sorted. data is then projected
adjusted ran index ari
wo ways of grouping amples are compared the true labels and the cluster assignments produced by the algo
nmi or nomrlaized mutaul info:
how much infov the clsuter assignments share with the true lables

'''